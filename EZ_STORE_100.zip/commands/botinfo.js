const Discord = require("discord.js")



module.exports = {

    name: "botinfo", // Coloque o nome do comando do arquivo

    aliases: ["infobot"], // Coloque sinônimos aqui



    run: async (client, message, args) => {



        let servidor = client.guilds.cache.size;

        let usuarios = client.users.cache.size;

        let canais = client.channels.cache.size;

        let ping = client.ws.ping;

        let dono_id = "1100060099604660226"; // Seu ID

        let dono = client.users.cache.get(dono_id);

        let prefixo = ".";

        let versao = "1.6";



        let embed = new Discord.MessageEmbed()

            .setColor("#ffffff")

            .setTimestamp(new Date)

            .setDescription(`⚒️  | Olá, tudo bem? me chamo, **${client.user.username}**  e fui desenvolvido por M4#8878, um sistema avançado.





\ **・👤 | Desenvolvedores: ** M4#8878

\ **・🌐 | Linguagem: ** [node.js](https://nodejs.org/en/)

\ **・⚙️ | Versão: ** ${versao}



\ **・🏓 | Ping:** ${ping}`);







        message.reply({ embeds: [embed] })







    }

}